class ascii{
	public static void main(String args[])
	{
	char c;
	int c1;
	c='X';
	System.out.println("Character is: "+c);
	c1=c;
	System.out.println("Integer representation of character is: "+c1);
	}
}