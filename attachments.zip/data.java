import java.io.*;
public class data
{
	public static void main(String[] args)
	{
		System.out.println("S.No.  Data Type    Size                        Minimum Value                                  Maximum Value");
		System.out.println("1.     Byte         1 byte                     -128                                            127");
		System.out.println("2.     Short        2 bytes                    -32,768                                         32,767");
		System.out.println("3.     Int          4 bytes                    -2,147,483,648                                  2,147,483, 647");
		System.out.println("4.     Long         8 bytes                    -9,223,372,036,854,775,808                      9,223,372,036,854,775,807");
		System.out.println("5.     Float        4 bytes                     approximately -3.40282347E+38F                 approximately +3.40282347E+38F");
		System.out.println("6.     Double       8 bytes                     approximately -1.79769313486231570E+308        approximately +1.79769313486231570E+308");
		System.out.println("7.     Char         2 byte                      0                                              65,536 (unsigned)"); 
		System.out.println("8.     Boolean      Not precisely defined*      True                                           False");
	} 
} 
