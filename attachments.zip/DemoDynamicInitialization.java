class DemoDynamicInitialization{
	public static void main(String args[])
	{
	int num, num1;
	num = 100;
	num1 = num/2;
	System.out.println("This is num: "+num);
	System.out.println(num1);
	}
}