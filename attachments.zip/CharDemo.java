class CharDemo {
	public static void main(String args[])
	{
	char ch1, ch2;
	ch1 = 88;
	ch2 = 'Y';
	System.out.print("ch1 and ch2: ");
	System.out.println(ch1 + " " + ch2);
	ch1++;
	System.out.println("ch1 is now " + ch1);
	}
}