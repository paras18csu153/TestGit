class add{
	public static void main(String args[])
	{
	int x, y, z;
	x = 10;
	y = 15;
	System.out.println("x and y are: "+x +" "+y);
	z = x+y;
	System.out.println("Sum of x and y is: "+z);
	}
}