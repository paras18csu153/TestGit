class DisplayHello {
public static void main( String args[] )
{
      System.out.print( "Hello " );
      System.out.println( "Hello!" );
      System.out.print( "Hello " );
  }
}