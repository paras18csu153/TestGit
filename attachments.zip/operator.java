class operator{
	public static void main(String args[])
	{
	int a, b;
	a=15;
	b=10;
	System.out.println("a and b: "+a +" " +b);
	System.out.println("Addition:" +(a+b));
	System.out.println("Subtraction:" +(a-b));
	System.out.println("Multiplication:" +(a*b));
	System.out.println("Division:" +(a/b));
	System.out.println("Modulus:" +(a%b));
	}
}