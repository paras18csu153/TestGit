class DemoInt{
	public static void main(String args[])
	{
	int num;
	num=100;
	System.out.println("This is num: " + num);
	num = num * 2;
	System.out.print("The value of num * 2 is ");
	System.out.println(num);
	}
}