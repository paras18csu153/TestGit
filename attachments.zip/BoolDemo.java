class BoolDemo {
	public static void main(String args[])
	{
	boolean b;
	b = false;
	System.out.println("b is "+b);
	b=true;
	System.out.println("b is "+b);
	System.out.println("10 > 9 is " + (10>9));
	}
}